package applogic;

public class LoginHelper1 extends DriverBasedHelper {

	public LoginHelper1(ApplicationManager1 manager) {
		super(manager);
	}

//	public HomePage simpleLogin(User u) {
//
//		return pages.menusPage.clickLogin().setEmail(u.getEmail()).setPassword(u.getPassword()).clickLoginButton();
//	}
//
//	public HomePage logout() {
//		return pages.menusPage.logout();
//	}

}
