package pages.super_pages;

import pages._pages_mngt.MainPageManager;

public abstract class AnyPage extends Page {

	public AnyPage(MainPageManager pages) {
		super(pages);
	}

}